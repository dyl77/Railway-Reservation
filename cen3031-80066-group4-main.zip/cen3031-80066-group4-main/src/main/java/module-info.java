module cen3031.group4.trainTickets {
    requires javafx.controls;
	requires java.sql;
	requires javafx.graphics;
	requires javafx.base;
    exports cen3031.group4.trainTickets;
}